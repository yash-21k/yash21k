-- ============================================================
--  Cloud Spanner DDL — run this once to create the target table
-- ============================================================

-- Apply with gcloud:
--   gcloud spanner databases ddl update orders-db \
--     --instance=main-instance                    \
--     --ddl-file=spanner-ddl.sql

CREATE TABLE Orders (
    OrderId      STRING(36)   NOT NULL,  -- UUID primary key
    CustomerId   STRING(36)   NOT NULL,
    ProductSku   STRING(64)   NOT NULL,
    Quantity     INT64        NOT NULL,
    UnitPrice    FLOAT64      NOT NULL,
    Status       STRING(32)   NOT NULL,  -- PENDING | CONFIRMED | SHIPPED | CANCELLED
    CreatedAt    TIMESTAMP    NOT NULL OPTIONS (allow_commit_timestamp=true),
    UpdatedAt    TIMESTAMP             OPTIONS (allow_commit_timestamp=true),
) PRIMARY KEY (OrderId);

-- Optional: index on CustomerId for per-customer queries
CREATE INDEX OrdersByCustomer ON Orders (CustomerId);

-- Optional: index on Status for operational dashboards
CREATE INDEX OrdersByStatus ON Orders (Status);
