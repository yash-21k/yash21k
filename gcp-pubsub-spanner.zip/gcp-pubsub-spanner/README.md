# GCP Pub/Sub → Spanner Pipeline

A minimal but production-ready Java 17 / Maven project that:

1. **Subscribes** to a GCP Pub/Sub pull subscription.
2. **Deserialises** each message body (JSON) into an `OrderEvent` POJO.
3. **Writes** every field of the POJO as a row in a Cloud Spanner table.

---

## Architecture

```
 GCP Pub/Sub
 ┌─────────────────────────┐
 │  Topic: orders-topic    │
 │  Subscription: orders-  │
 │    subscription         │
 └────────────┬────────────┘
              │  pull (async)
              ▼
 ┌─────────────────────────┐        ┌─────────────────────────┐
 │   PubSubSubscriber      │──────▶│   JsonDeserializer       │
 │   (MessageReceiver)     │        │   (Jackson ObjectMapper) │
 └─────────────────────────┘        └────────────┬────────────┘
                                                  │  OrderEvent POJO
                                                  ▼
                                     ┌────────────────────────┐
                                     │   SpannerWriter         │
                                     │   Mutation.insertOrUpdate│
                                     └────────────┬───────────┘
                                                  │
                                                  ▼
                                     ┌────────────────────────┐
                                     │  Cloud Spanner          │
                                     │  Table: Orders          │
                                     └────────────────────────┘
```

---

## Project structure

```
gcp-pubsub-spanner/
├── pom.xml
├── spanner-ddl.sql                         ← run once to create the table
└── src/main/java/com/example/pipeline/
    ├── PipelineApplication.java            ← main() entry point
    ├── config/
    │   └── PipelineConfig.java             ← env-var driven config
    ├── model/
    │   └── OrderEvent.java                 ← POJO ↔ JSON ↔ Spanner row
    ├── subscriber/
    │   ├── PubSubSubscriber.java           ← async pull subscriber
    │   └── JsonDeserializer.java           ← JSON → POJO (Jackson)
    └── spanner/
        └── SpannerWriter.java              ← POJO → Spanner mutation
```

---

## Spanner table

Apply `spanner-ddl.sql` once:

```bash
gcloud spanner databases ddl update orders-db \
  --instance=main-instance \
  --ddl-file=spanner-ddl.sql
```

Column mapping:

| Java field (`OrderEvent`) | Spanner column | Type        |
|---------------------------|----------------|-------------|
| `orderId`                 | `OrderId`      | STRING(36)  |
| `customerId`              | `CustomerId`   | STRING(36)  |
| `productSku`              | `ProductSku`   | STRING(64)  |
| `quantity`                | `Quantity`     | INT64       |
| `unitPrice`               | `UnitPrice`    | FLOAT64     |
| `status`                  | `Status`       | STRING(32)  |
| `createdAt`               | `CreatedAt`    | TIMESTAMP   |
| `updatedAt`               | `UpdatedAt`    | TIMESTAMP   |

---

## Sample Pub/Sub message (JSON)

```json
{
  "order_id"    : "a1b2c3d4-1111-2222-3333-444455556666",
  "customer_id" : "cust-001",
  "product_sku" : "WIDGET-XL",
  "quantity"    : 3,
  "unit_price"  : 19.99,
  "status"      : "PENDING",
  "created_at"  : "2024-06-15T10:30:00Z",
  "updated_at"  : "2024-06-15T10:35:00Z"
}
```

Publish a test message:

```bash
gcloud pubsub topics publish orders-topic --message='{ ... }'
```

---

## Running locally

```bash
# Authenticate
gcloud auth application-default login

# Set environment variables
export GCP_PROJECT_ID=my-gcp-project
export PUBSUB_SUBSCRIPTION_ID=orders-subscription
export SPANNER_INSTANCE_ID=main-instance
export SPANNER_DATABASE_ID=orders-db

# Build & run
mvn package -q
java -jar target/gcp-pubsub-spanner-1.0.0-SNAPSHOT.jar
```

---

## Key design decisions

| Decision | Rationale |
|----------|-----------|
| `INSERT_OR_UPDATE` mutation | Re-delivered Pub/Sub messages are idempotent; no duplicate rows. |
| NACK on failure | Pub/Sub retries with exponential back-off; no message is silently dropped. |
| Shared `ObjectMapper` | Thread-safe after construction; avoids repeated initialisation cost. |
| Shutdown hook | Ensures in-flight messages are ACK'd / NACK'd before the JVM exits. |
