package com.example.pipeline;

import com.example.pipeline.config.PipelineConfig;
import com.example.pipeline.spanner.SpannerWriter;
import com.example.pipeline.subscriber.PubSubSubscriber;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Entry point for the <strong>Pub/Sub → Spanner</strong> pipeline.
 *
 * <pre>
 * Start-up sequence
 * ─────────────────
 *  1. Load PipelineConfig from environment variables.
 *  2. Create a SpannerWriter (opens a connection to Cloud Spanner).
 *  3. Create a PubSubSubscriber (registers the MessageReceiver).
 *  4. Register a JVM shutdown hook for graceful teardown.
 *  5. Start pulling messages; block until the JVM exits.
 *
 * How to run locally (Application Default Credentials)
 * ────────────────────────────────────────────────────
 *  $ gcloud auth application-default login
 *  $ export GCP_PROJECT_ID=my-project
 *  $ export PUBSUB_SUBSCRIPTION_ID=orders-subscription
 *  $ export SPANNER_INSTANCE_ID=main-instance
 *  $ export SPANNER_DATABASE_ID=orders-db
 *  $ mvn package -q
 *  $ java -jar target/gcp-pubsub-spanner-1.0.0-SNAPSHOT.jar
 * </pre>
 */
public class PipelineApplication {

    private static final Logger log = LoggerFactory.getLogger(PipelineApplication.class);

    public static void main(String[] args) {

        // ── 1. Config ──────────────────────────────────────────────────────
        PipelineConfig config = PipelineConfig.fromEnvironment();
        log.info("Starting pipeline with config: {}", config);

        // ── 2. Spanner writer ──────────────────────────────────────────────
        SpannerWriter spannerWriter = new SpannerWriter(config);

        // ── 3. Pub/Sub subscriber ──────────────────────────────────────────
        PubSubSubscriber subscriber = new PubSubSubscriber(config, spannerWriter);

        // ── 4. Graceful shutdown hook ──────────────────────────────────────
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            log.info("Shutdown signal received — tearing down pipeline …");
            subscriber.close();
            spannerWriter.close();
            log.info("Pipeline shut down cleanly. Goodbye!");
        }, "shutdown-hook"));

        // ── 5. Start and block ─────────────────────────────────────────────
        subscriber.startAsync();
        subscriber.awaitTermination();
    }
}
