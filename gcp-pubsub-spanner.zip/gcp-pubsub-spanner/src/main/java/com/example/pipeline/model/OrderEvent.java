package com.example.pipeline.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;

/**
 * Domain object that is:
 *  1. Deserialised from the raw JSON arriving on the Pub/Sub subscription.
 *  2. Written column-by-column into the Spanner table  `Orders`.
 *
 * <pre>
 * Spanner DDL
 * ───────────
 * CREATE TABLE Orders (
 *     OrderId      STRING(36)   NOT NULL,
 *     CustomerId   STRING(36)   NOT NULL,
 *     ProductSku   STRING(64)   NOT NULL,
 *     Quantity     INT64        NOT NULL,
 *     UnitPrice    FLOAT64      NOT NULL,
 *     Status       STRING(32)   NOT NULL,
 *     CreatedAt    TIMESTAMP    NOT NULL,
 *     UpdatedAt    TIMESTAMP,
 * ) PRIMARY KEY (OrderId);
 * </pre>
 *
 * Sample JSON message on the Pub/Sub topic:
 * <pre>
 * {
 *   "order_id"    : "a1b2c3d4-...",
 *   "customer_id" : "cust-001",
 *   "product_sku" : "WIDGET-XL",
 *   "quantity"    : 3,
 *   "unit_price"  : 19.99,
 *   "status"      : "PENDING",
 *   "created_at"  : "2024-06-15T10:30:00Z",
 *   "updated_at"  : "2024-06-15T10:30:00Z"
 * }
 * </pre>
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderEvent {

    @JsonProperty("order_id")
    private String orderId;

    @JsonProperty("customer_id")
    private String customerId;

    @JsonProperty("product_sku")
    private String productSku;

    @JsonProperty("quantity")
    private int quantity;

    @JsonProperty("unit_price")
    private double unitPrice;

    @JsonProperty("status")
    private String status;

    @JsonProperty("created_at")
    private Instant createdAt;

    @JsonProperty("updated_at")
    private Instant updatedAt;

    // ── Constructors ───────────────────────────────────────────────────────

    public OrderEvent() { /* Jackson needs a no-arg constructor */ }

    public OrderEvent(String orderId, String customerId, String productSku,
                      int quantity, double unitPrice, String status,
                      Instant createdAt, Instant updatedAt) {
        this.orderId     = orderId;
        this.customerId  = customerId;
        this.productSku  = productSku;
        this.quantity    = quantity;
        this.unitPrice   = unitPrice;
        this.status      = status;
        this.createdAt   = createdAt;
        this.updatedAt   = updatedAt;
    }

    // ── Getters / setters ──────────────────────────────────────────────────

    public String getOrderId()            { return orderId; }
    public void   setOrderId(String v)    { this.orderId = v; }

    public String getCustomerId()         { return customerId; }
    public void   setCustomerId(String v) { this.customerId = v; }

    public String getProductSku()         { return productSku; }
    public void   setProductSku(String v) { this.productSku = v; }

    public int    getQuantity()           { return quantity; }
    public void   setQuantity(int v)      { this.quantity = v; }

    public double getUnitPrice()          { return unitPrice; }
    public void   setUnitPrice(double v)  { this.unitPrice = v; }

    public String getStatus()             { return status; }
    public void   setStatus(String v)     { this.status = v; }

    public Instant getCreatedAt()         { return createdAt; }
    public void    setCreatedAt(Instant v){ this.createdAt = v; }

    public Instant getUpdatedAt()         { return updatedAt; }
    public void    setUpdatedAt(Instant v){ this.updatedAt = v; }

    @Override
    public String toString() {
        return "OrderEvent{" +
               "orderId='"    + orderId    + '\'' +
               ", customerId='"+ customerId + '\'' +
               ", productSku='"+ productSku + '\'' +
               ", quantity="  + quantity   +
               ", unitPrice=" + unitPrice  +
               ", status='"   + status     + '\'' +
               ", createdAt=" + createdAt  +
               ", updatedAt=" + updatedAt  +
               '}';
    }
}
