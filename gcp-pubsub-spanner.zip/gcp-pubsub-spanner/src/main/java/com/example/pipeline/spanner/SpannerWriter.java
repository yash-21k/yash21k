package com.example.pipeline.spanner;

import com.example.pipeline.config.PipelineConfig;
import com.example.pipeline.model.OrderEvent;
import com.google.cloud.Timestamp;
import com.google.cloud.spanner.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Closeable;
import java.util.Collections;

/**
 * Writes {@link OrderEvent} objects to Cloud Spanner using
 * {@link Mutation#newInsertOrUpdateBuilder} (upsert semantics).
 *
 * <p>Each call to {@link #write} opens a short-lived read-write transaction
 * and commits one mutation.  For high-throughput scenarios this can be
 * extended to batch multiple mutations per commit.
 *
 * <h3>Spanner table expected</h3>
 * <pre>
 * CREATE TABLE Orders (
 *     OrderId      STRING(36)   NOT NULL,
 *     CustomerId   STRING(36)   NOT NULL,
 *     ProductSku   STRING(64)   NOT NULL,
 *     Quantity     INT64        NOT NULL,
 *     UnitPrice    FLOAT64      NOT NULL,
 *     Status       STRING(32)   NOT NULL,
 *     CreatedAt    TIMESTAMP    NOT NULL,
 *     UpdatedAt    TIMESTAMP,
 * ) PRIMARY KEY (OrderId);
 * </pre>
 */
public class SpannerWriter implements Closeable {

    private static final Logger log = LoggerFactory.getLogger(SpannerWriter.class);

    private final String       tableName;
    private final Spanner      spanner;
    private final DatabaseClient dbClient;

    // ── Construction ───────────────────────────────────────────────────────

    public SpannerWriter(PipelineConfig config) {
        this.tableName = config.spannerTableName;

        SpannerOptions options = SpannerOptions.newBuilder()
                .setProjectId(config.projectId)
                .build();

        this.spanner  = options.getService();
        this.dbClient = spanner.getDatabaseClient(
                DatabaseId.of(
                        config.projectId,
                        config.spannerInstanceId,
                        config.spannerDatabaseId));

        log.info("SpannerWriter initialised → project={} instance={} database={} table={}",
                 config.projectId, config.spannerInstanceId,
                 config.spannerDatabaseId, config.spannerTableName);
    }

    // ── Public API ─────────────────────────────────────────────────────────

    /**
     * Converts every field of the {@link OrderEvent} into a Spanner column
     * and commits the mutation.  Uses INSERT_OR_UPDATE so re-delivered
     * Pub/Sub messages are idempotent.
     *
     * @param event the fully-populated order object
     */
    public void write(OrderEvent event) {
        // ── 1. Map each Java field to the matching Spanner column ──────────
        Mutation mutation = Mutation
                .newInsertOrUpdateBuilder(tableName)

                // STRING columns
                .set("OrderId")    .to(event.getOrderId())
                .set("CustomerId") .to(event.getCustomerId())
                .set("ProductSku") .to(event.getProductSku())
                .set("Status")     .to(event.getStatus())

                // Numeric columns
                .set("Quantity")   .to(event.getQuantity())   // INT64
                .set("UnitPrice")  .to(event.getUnitPrice())  // FLOAT64

                // TIMESTAMP columns — convert java.time.Instant → Cloud Timestamp
                .set("CreatedAt")  .to(toSpannerTimestamp(event.getCreatedAt()))
                .set("UpdatedAt")  .to(event.getUpdatedAt() != null
                                        ? toSpannerTimestamp(event.getUpdatedAt())
                                        : null)
                .build();

        // ── 2. Commit the single mutation ──────────────────────────────────
        dbClient.write(Collections.singletonList(mutation));

        log.info("✔ Written to Spanner — OrderId={} CustomerId={} Status={}",
                 event.getOrderId(), event.getCustomerId(), event.getStatus());
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private static Timestamp toSpannerTimestamp(java.time.Instant instant) {
        return Timestamp.ofTimeSecondsAndNanos(
                instant.getEpochSecond(),
                instant.getNano());
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────

    @Override
    public void close() {
        if (spanner != null) {
            spanner.close();
            log.info("SpannerWriter closed.");
        }
    }
}
