package com.example.pipeline.subscriber;

import com.example.pipeline.model.OrderEvent;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Converts a raw JSON string (from a Pub/Sub message body) into an
 * {@link OrderEvent} POJO.
 *
 * <p>A single shared {@link ObjectMapper} instance is kept here since it is
 * thread-safe after construction and expensive to create.
 */
public class JsonDeserializer {

    private static final Logger log = LoggerFactory.getLogger(JsonDeserializer.class);

    /** Shared, thread-safe ObjectMapper configured for java.time types. */
    private static final ObjectMapper MAPPER = buildMapper();

    private static ObjectMapper buildMapper() {
        return new ObjectMapper()
                // Support java.time.Instant, LocalDate, etc.
                .registerModule(new JavaTimeModule())
                // Write Instants as ISO-8601 strings, not epoch millis
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    }

    // Private constructor — utility class, no instances needed.
    private JsonDeserializer() {}

    /**
     * Deserialises a JSON string into an {@link OrderEvent}.
     *
     * @param json raw UTF-8 JSON payload from Pub/Sub
     * @return a fully populated {@link OrderEvent}
     * @throws RuntimeException wrapping any JSON parse error
     */
    public static OrderEvent deserialize(String json) {
        try {
            OrderEvent event = MAPPER.readValue(json, OrderEvent.class);
            log.debug("Deserialised message → {}", event);
            return event;
        } catch (Exception e) {
            log.error("Failed to deserialise JSON payload: {}", json, e);
            throw new RuntimeException("JSON deserialisation failed", e);
        }
    }
}
