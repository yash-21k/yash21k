package com.example.pipeline.config;

/**
 * Central place for every GCP resource coordinate used in this pipeline.
 *
 * Values are read from environment variables first; sensible defaults are
 * provided so the project compiles and runs locally without extra setup.
 *
 * ┌─────────────────────────────────────────────────────────────────────┐
 * │  Environment variables you MUST set in production / CI              │
 * ├────────────────────────────┬────────────────────────────────────────┤
 * │  GCP_PROJECT_ID            │  your-gcp-project                      │
 * │  PUBSUB_SUBSCRIPTION_ID    │  orders-subscription                   │
 * │  SPANNER_INSTANCE_ID       │  main-instance                         │
 * │  SPANNER_DATABASE_ID       │  orders-db                             │
 * └────────────────────────────┴────────────────────────────────────────┘
 */
public final class PipelineConfig {

    // ── GCP project ────────────────────────────────────────────────────────
    public final String projectId;

    // ── Pub/Sub ────────────────────────────────────────────────────────────
    public final String subscriptionId;

    // ── Spanner ────────────────────────────────────────────────────────────
    public final String spannerInstanceId;
    public final String spannerDatabaseId;
    public final String spannerTableName;

    // ── Tuning ────────────────────────────────────────────────────────────
    /** Max messages pulled from Pub/Sub before the subscriber pauses. */
    public final int maxOutstandingMessages;

    private PipelineConfig(Builder b) {
        this.projectId              = b.projectId;
        this.subscriptionId         = b.subscriptionId;
        this.spannerInstanceId      = b.spannerInstanceId;
        this.spannerDatabaseId      = b.spannerDatabaseId;
        this.spannerTableName       = b.spannerTableName;
        this.maxOutstandingMessages = b.maxOutstandingMessages;
    }

    /** Load config from environment variables, falling back to sensible defaults. */
    public static PipelineConfig fromEnvironment() {
        return new Builder()
            .projectId(env("GCP_PROJECT_ID", "my-gcp-project"))
            .subscriptionId(env("PUBSUB_SUBSCRIPTION_ID", "orders-subscription"))
            .spannerInstanceId(env("SPANNER_INSTANCE_ID", "main-instance"))
            .spannerDatabaseId(env("SPANNER_DATABASE_ID", "orders-db"))
            .spannerTableName(env("SPANNER_TABLE_NAME", "Orders"))
            .maxOutstandingMessages(Integer.parseInt(env("MAX_OUTSTANDING_MSGS", "100")))
            .build();
    }

    private static String env(String key, String defaultValue) {
        String value = System.getenv(key);
        return (value != null && !value.isBlank()) ? value : defaultValue;
    }

    @Override
    public String toString() {
        return "PipelineConfig{" +
               "projectId='"         + projectId         + '\'' +
               ", subscriptionId='"  + subscriptionId    + '\'' +
               ", spannerInstance='" + spannerInstanceId + '\'' +
               ", spannerDatabase='" + spannerDatabaseId + '\'' +
               ", spannerTable='"    + spannerTableName  + '\'' +
               '}';
    }

    // ── Builder ────────────────────────────────────────────────────────────

    public static final class Builder {
        private String projectId             = "my-gcp-project";
        private String subscriptionId        = "orders-subscription";
        private String spannerInstanceId     = "main-instance";
        private String spannerDatabaseId     = "orders-db";
        private String spannerTableName      = "Orders";
        private int    maxOutstandingMessages = 100;

        public Builder projectId(String v)             { projectId = v;             return this; }
        public Builder subscriptionId(String v)        { subscriptionId = v;        return this; }
        public Builder spannerInstanceId(String v)     { spannerInstanceId = v;     return this; }
        public Builder spannerDatabaseId(String v)     { spannerDatabaseId = v;     return this; }
        public Builder spannerTableName(String v)      { spannerTableName = v;      return this; }
        public Builder maxOutstandingMessages(int v)   { maxOutstandingMessages = v;return this; }
        public PipelineConfig build()                  { return new PipelineConfig(this); }
    }
}
