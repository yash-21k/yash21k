package com.example.pipeline.subscriber;

import com.example.pipeline.config.PipelineConfig;
import com.example.pipeline.model.OrderEvent;
import com.example.pipeline.spanner.SpannerWriter;
import com.google.cloud.pubsub.v1.AckReplyConsumer;
import com.google.cloud.pubsub.v1.MessageReceiver;
import com.google.cloud.pubsub.v1.Subscriber;
import com.google.pubsub.v1.ProjectSubscriptionName;
import com.google.pubsub.v1.PubsubMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Closeable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Binds a GCP Pub/Sub <em>pull subscription</em> to the processing pipeline.
 *
 * <p>Flow per message:
 * <ol>
 *   <li>Pub/Sub delivers a {@link PubsubMessage}.
 *   <li>{@link JsonDeserializer#deserialize} converts the UTF-8 body to an
 *       {@link OrderEvent} POJO.
 *   <li>{@link SpannerWriter#write} maps every field to a Spanner column and
 *       commits an INSERT_OR_UPDATE mutation.
 *   <li>On success the message is ACK'd; on failure it is NACK'd so Pub/Sub
 *       will redeliver it (with exponential back-off).
 * </ol>
 *
 * <h3>Threading</h3>
 * The underlying {@link Subscriber} uses a thread pool; multiple messages can
 * be processed concurrently.  {@link SpannerWriter} is thread-safe.
 */
public class PubSubSubscriber implements Closeable {

    private static final Logger log = LoggerFactory.getLogger(PubSubSubscriber.class);

    private final Subscriber     subscriber;
    private final SpannerWriter  spannerWriter;

    // ── Construction ───────────────────────────────────────────────────────

    public PubSubSubscriber(PipelineConfig config, SpannerWriter spannerWriter) {
        this.spannerWriter = spannerWriter;

        ProjectSubscriptionName subscriptionName =
                ProjectSubscriptionName.of(config.projectId, config.subscriptionId);

        // ── Message handler ────────────────────────────────────────────────
        MessageReceiver receiver = (PubsubMessage message, AckReplyConsumer consumer) -> {
            String messageId  = message.getMessageId();
            String rawPayload = message.getData().toStringUtf8();

            log.info("▶ Received message id={} size={} bytes",
                     messageId, rawPayload.length());

            try {
                // ── Step 1: JSON → POJO ────────────────────────────────────
                OrderEvent event = JsonDeserializer.deserialize(rawPayload);

                // ── Step 2: POJO fields → Spanner row ──────────────────────
                spannerWriter.write(event);

                // ── Step 3: ACK – tell Pub/Sub we're done ──────────────────
                consumer.ack();
                log.info("✔ ACK message id={}", messageId);

            } catch (Exception ex) {
                // NACK – Pub/Sub will redeliver (with back-off)
                consumer.nack();
                log.error("✘ NACK message id={} — will be redelivered. Cause: {}",
                          messageId, ex.getMessage(), ex);
            }
        };

        // ── Build the subscriber ───────────────────────────────────────────
        this.subscriber = Subscriber.newBuilder(subscriptionName, receiver)
                .build();

        log.info("PubSubSubscriber created for subscription '{}'",
                 subscriptionName.toString());
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────

    /** Start pulling messages asynchronously. */
    public void startAsync() {
        subscriber.startAsync().awaitRunning();
        log.info("PubSubSubscriber is RUNNING — listening for messages …");
    }

    /**
     * Block the calling thread until the subscriber stops or the JVM shuts
     * down via the registered shutdown hook.
     */
    public void awaitTermination() {
        try {
            subscriber.awaitTerminated();
        } catch (IllegalStateException e) {
            log.warn("Subscriber terminated with error: {}", e.getMessage());
        }
    }

    /** Gracefully stop pulling; waits up to 30 s for in-flight messages. */
    public void stopGracefully() {
        log.info("Stopping PubSubSubscriber …");
        subscriber.stopAsync();
        try {
            subscriber.awaitTerminated(30, TimeUnit.SECONDS);
            log.info("PubSubSubscriber stopped cleanly.");
        } catch (TimeoutException e) {
            log.warn("Subscriber did not stop within 30 s; forcing shutdown.");
        }
    }

    @Override
    public void close() {
        stopGracefully();
    }
}
