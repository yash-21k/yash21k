package com.example.pipeline.subscriber;

import com.example.pipeline.model.OrderEvent;
import org.junit.jupiter.api.Test;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for {@link JsonDeserializer}.
 * No GCP credentials required — pure in-process JSON parsing.
 */
class JsonDeserializerTest {

    private static final String VALID_JSON = """
            {
              "order_id"    : "a1b2c3d4-1111-2222-3333-444455556666",
              "customer_id" : "cust-001",
              "product_sku" : "WIDGET-XL",
              "quantity"    : 3,
              "unit_price"  : 19.99,
              "status"      : "PENDING",
              "created_at"  : "2024-06-15T10:30:00Z",
              "updated_at"  : "2024-06-15T10:35:00Z"
            }
            """;

    @Test
    void shouldDeserialiseAllFields() {
        OrderEvent event = JsonDeserializer.deserialize(VALID_JSON);

        assertAll("OrderEvent fields",
            () -> assertEquals("a1b2c3d4-1111-2222-3333-444455556666", event.getOrderId()),
            () -> assertEquals("cust-001",  event.getCustomerId()),
            () -> assertEquals("WIDGET-XL", event.getProductSku()),
            () -> assertEquals(3,           event.getQuantity()),
            () -> assertEquals(19.99,       event.getUnitPrice(), 0.001),
            () -> assertEquals("PENDING",   event.getStatus()),
            () -> assertEquals(Instant.parse("2024-06-15T10:30:00Z"), event.getCreatedAt()),
            () -> assertEquals(Instant.parse("2024-06-15T10:35:00Z"), event.getUpdatedAt())
        );
    }

    @Test
    void shouldIgnoreExtraUnknownFields() {
        String jsonWithExtra = """
                { "order_id": "oid-1", "customer_id": "c1",
                  "product_sku": "SKU", "quantity": 1, "unit_price": 5.0,
                  "status": "NEW", "created_at": "2024-01-01T00:00:00Z",
                  "unknown_field": "should be ignored" }
                """;
        assertDoesNotThrow(() -> JsonDeserializer.deserialize(jsonWithExtra));
    }

    @Test
    void shouldThrowOnMalformedJson() {
        assertThrows(RuntimeException.class,
            () -> JsonDeserializer.deserialize("{ this is not json }"));
    }
}
